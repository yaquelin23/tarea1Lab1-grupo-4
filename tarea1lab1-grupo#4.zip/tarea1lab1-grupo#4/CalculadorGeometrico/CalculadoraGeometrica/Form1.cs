using System;
using System.Windows.Forms;

namespace CalculadoraGeometrica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcularRombo_Click(object sender, EventArgs e)
        {
            double diagonalMayor, diagonalMenor, ladoRombo;

            if (double.TryParse(textBoxDiagonalMayor.Text, out diagonalMayor) &&
                double.TryParse(textBoxDiagonalMenor.Text, out diagonalMenor) &&
                double.TryParse(textBoxLado.Text, out ladoRombo))
            {
                Rombo rombo = new Rombo
                {
                    DiagonalMayor = diagonalMayor,
                    DiagonalMenor = diagonalMenor,
                    Lado = ladoRombo
                };

                double areaRombo = rombo.CalcularArea();
                double perimetroRombo = rombo.CalcularPerimetro();

                labelAreaRombo.Text = $"�rea del Rombo: {areaRombo}";
                labelPerimetroRombo.Text = $"Per�metro del Rombo: {perimetroRombo}";
            }
            else
            {
                MessageBox.Show("Por favor, ingrese valores num�ricos v�lidos en todos los campos del rombo.");
            }
        }

        private void buttonCalcularHexagono_Click(object sender, EventArgs e)
        {
            double ladoHexagono;

            if (double.TryParse(textBoxLadoHex.Text, out ladoHexagono))
            {
                Hexagono hexagono = new Hexagono
                {
                    Lado = ladoHexagono
                };

                double areaHexagono = hexagono.CalcularArea();
                double perimetroHexagono = hexagono.CalcularPerimetro();

                labelAreaHex.Text = $"�rea del Hex�gono: {areaHexagono}";
                labelPerimetroHex.Text = $"Per�metro del Hex�gono: {perimetroHexagono}";
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un valor num�rico v�lido en el campo del hex�gono.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
    }
}
