﻿namespace CalculadoraGeometrica
{
    public class Rombo
    {
        public double DiagonalMayor { get; set; }
        public double DiagonalMenor { get; set; }
        public double Lado { get; set; }

        public double CalcularArea()
        {
            return (DiagonalMayor * DiagonalMenor) / 2;
        }

        public double CalcularPerimetro()
        {
            return 4 * Lado;
        }
    }
}
