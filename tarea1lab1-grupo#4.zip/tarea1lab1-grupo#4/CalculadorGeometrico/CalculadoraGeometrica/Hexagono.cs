﻿namespace CalculadoraGeometrica
{
    public class Hexagono
    {
        public double Lado { get; set; }

        public double CalcularArea()
        {
            return ((3 * Math.Sqrt(3)) / 2) * Math.Pow(Lado, 2);
        }

        public double CalcularPerimetro()
        {
            return 6 * Lado;
        }
    }
}
