using System;
using System.Windows.Forms;

namespace EnterKeyPressApp
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true; 
            this.KeyDown += new KeyEventHandler(Form1_KeyDown); 
        }

      
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                labelMessage.Text = "Cuidado. No se permite presionar la tecla ENTER";
                e.Handled = true; // Detiene el evento ENTER
            }
            else
            {
                labelMessage.Text = ""; 
            }
        }
    }
}
