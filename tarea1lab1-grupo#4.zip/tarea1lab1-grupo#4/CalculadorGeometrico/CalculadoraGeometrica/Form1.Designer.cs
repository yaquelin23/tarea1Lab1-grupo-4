﻿namespace CalculadoraGeometrica
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            labelDiagonalMayor = new Label();
            labelDiagonalMenor = new Label();
            textBoxDiagonalMayor = new TextBox();
            buttonCalcularHexagono = new Button();
            labelLado = new Label();
            labelAreaRombo = new Label();
            labelPerimetroRombo = new Label();
            labelLadoHex = new Label();
            textBoxDiagonalMenor = new TextBox();
            buttonCalcularRombo = new Button();
            label7 = new Label();
            labelAreaHex = new Label();
            labelPerimetroHex = new Label();
            textBoxLado = new TextBox();
            textBoxLadoHex = new TextBox();
            SuspendLayout();
            // 
            // labelDiagonalMayor
            // 
            labelDiagonalMayor.AutoSize = true;
            labelDiagonalMayor.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            labelDiagonalMayor.Location = new Point(49, 64);
            labelDiagonalMayor.Name = "labelDiagonalMayor";
            labelDiagonalMayor.Size = new Size(120, 20);
            labelDiagonalMayor.TabIndex = 0;
            labelDiagonalMayor.Text = "Diagonal Mayor";
            // 
            // labelDiagonalMenor
            // 
            labelDiagonalMenor.AutoSize = true;
            labelDiagonalMenor.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            labelDiagonalMenor.Location = new Point(49, 113);
            labelDiagonalMenor.Name = "labelDiagonalMenor";
            labelDiagonalMenor.Size = new Size(121, 20);
            labelDiagonalMenor.TabIndex = 1;
            labelDiagonalMenor.Text = "Diagonal Menor";
            // 
            // textBoxDiagonalMayor
            // 
            textBoxDiagonalMayor.Location = new Point(191, 64);
            textBoxDiagonalMayor.Name = "textBoxDiagonalMayor";
            textBoxDiagonalMayor.Size = new Size(306, 23);
            textBoxDiagonalMayor.TabIndex = 2;
            // 
            // buttonCalcularHexagono
            // 
            buttonCalcularHexagono.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            buttonCalcularHexagono.Location = new Point(295, 364);
            buttonCalcularHexagono.Name = "buttonCalcularHexagono";
            buttonCalcularHexagono.Size = new Size(188, 45);
            buttonCalcularHexagono.TabIndex = 3;
            buttonCalcularHexagono.Text = "Calcular Hexágono";
            buttonCalcularHexagono.UseVisualStyleBackColor = true;
            buttonCalcularHexagono.Click += buttonCalcularHexagono_Click;
            // 
            // labelLado
            // 
            labelLado.AutoSize = true;
            labelLado.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            labelLado.Location = new Point(532, 243);
            labelLado.Name = "labelLado";
            labelLado.Size = new Size(123, 20);
            labelLado.TabIndex = 4;
            labelLado.Text = "Lado del Rombo";
            // 
            // labelAreaRombo
            // 
            labelAreaRombo.AutoSize = true;
            labelAreaRombo.Location = new Point(560, 394);
            labelAreaRombo.Name = "labelAreaRombo";
            labelAreaRombo.Size = new Size(0, 15);
            labelAreaRombo.TabIndex = 5;
            // 
            // labelPerimetroRombo
            // 
            labelPerimetroRombo.AutoSize = true;
            labelPerimetroRombo.Location = new Point(560, 297);
            labelPerimetroRombo.Name = "labelPerimetroRombo";
            labelPerimetroRombo.Size = new Size(0, 15);
            labelPerimetroRombo.TabIndex = 6;
            // 
            // labelLadoHex
            // 
            labelLadoHex.AutoSize = true;
            labelLadoHex.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            labelLadoHex.Location = new Point(49, 200);
            labelLadoHex.Name = "labelLadoHex";
            labelLadoHex.Size = new Size(143, 20);
            labelLadoHex.TabIndex = 7;
            labelLadoHex.Text = "Lado del Hexágono";
            // 
            // textBoxDiagonalMenor
            // 
            textBoxDiagonalMenor.Location = new Point(191, 113);
            textBoxDiagonalMenor.Name = "textBoxDiagonalMenor";
            textBoxDiagonalMenor.Size = new Size(306, 23);
            textBoxDiagonalMenor.TabIndex = 8;
            // 
            // buttonCalcularRombo
            // 
            buttonCalcularRombo.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            buttonCalcularRombo.Location = new Point(295, 297);
            buttonCalcularRombo.Name = "buttonCalcularRombo";
            buttonCalcularRombo.Size = new Size(188, 43);
            buttonCalcularRombo.TabIndex = 9;
            buttonCalcularRombo.Text = "Calcular Rombo";
            buttonCalcularRombo.UseVisualStyleBackColor = true;
            buttonCalcularRombo.Click += buttonCalcularRombo_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Stencil", 12F, FontStyle.Bold);
            label7.Location = new Point(170, 18);
            label7.Name = "label7";
            label7.Size = new Size(331, 19);
            label7.TabIndex = 10;
            label7.Text = "Calculador de Áreas y Perímetros";
            // 
            // labelAreaHex
            // 
            labelAreaHex.AutoSize = true;
            labelAreaHex.Location = new Point(76, 297);
            labelAreaHex.Name = "labelAreaHex";
            labelAreaHex.Size = new Size(0, 15);
            labelAreaHex.TabIndex = 11;
            // 
            // labelPerimetroHex
            // 
            labelPerimetroHex.AutoSize = true;
            labelPerimetroHex.Location = new Point(76, 394);
            labelPerimetroHex.Name = "labelPerimetroHex";
            labelPerimetroHex.Size = new Size(0, 15);
            labelPerimetroHex.TabIndex = 12;
            // 
            // textBoxLado
            // 
            textBoxLado.Location = new Point(206, 200);
            textBoxLado.Name = "textBoxLado";
            textBoxLado.Size = new Size(291, 23);
            textBoxLado.TabIndex = 13;
            // 
            // textBoxLadoHex
            // 
            textBoxLadoHex.Location = new Point(206, 243);
            textBoxLadoHex.Name = "textBoxLadoHex";
            textBoxLadoHex.Size = new Size(291, 23);
            textBoxLadoHex.TabIndex = 14;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 563);
            Controls.Add(textBoxLadoHex);
            Controls.Add(textBoxLado);
            Controls.Add(labelPerimetroHex);
            Controls.Add(labelAreaHex);
            Controls.Add(label7);
            Controls.Add(buttonCalcularRombo);
            Controls.Add(textBoxDiagonalMenor);
            Controls.Add(labelLadoHex);
            Controls.Add(labelPerimetroRombo);
            Controls.Add(labelAreaRombo);
            Controls.Add(labelLado);
            Controls.Add(buttonCalcularHexagono);
            Controls.Add(textBoxDiagonalMayor);
            Controls.Add(labelDiagonalMenor);
            Controls.Add(labelDiagonalMayor);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label labelDiagonalMayor;
        private System.Windows.Forms.Label labelDiagonalMenor;
        private System.Windows.Forms.TextBox textBoxDiagonalMayor;
        private System.Windows.Forms.Button buttonCalcularHexagono;
        private System.Windows.Forms.Label labelLado;
        private System.Windows.Forms.Label labelAreaRombo;
        private System.Windows.Forms.Label labelPerimetroRombo;
        private System.Windows.Forms.Label labelLadoHex;
        private System.Windows.Forms.TextBox textBoxDiagonalMenor;
        private System.Windows.Forms.Button buttonCalcularRombo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelAreaHex;
        private System.Windows.Forms.Label labelPerimetroHex;
        private System.Windows.Forms.TextBox textBoxLado;
        private System.Windows.Forms.TextBox textBoxLadoHex;
    }
}
